# serverless-backend

## Simple Serveless Backend using Node.js on AWS Lambda
